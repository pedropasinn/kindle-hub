import React, { createContext, useContext, useEffect, useMemo, useReducer } from 'react'
import { loadState, saveState } from '../utils/storage.js'
import { createInitialState } from './schema.js'
import { reducer } from './reducer.js'

const Ctx = createContext(null)

export function AppProvider({ children }) {
  const persisted = loadState()
  const [state, dispatch] = useReducer(reducer, persisted || createInitialState())

  useEffect(() => {
    saveState(state)
  }, [state])

  const value = useMemo(() => ({ state, dispatch }), [state])
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>
}

export function useApp() {
  const v = useContext(Ctx)
  if (!v) throw new Error('useApp precisa estar dentro de <AppProvider/>')
  return v
}
