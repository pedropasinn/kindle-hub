import { uid } from '../utils/id.js'
import { todayISO } from '../utils/dates.js'

export const ACTIONS = {
  ADD_LOG: 'ADD_LOG',
  UPDATE_LOG: 'UPDATE_LOG',
  ADD_TASK: 'ADD_TASK',
  UPDATE_TASK: 'UPDATE_TASK',
  ADD_PROJECT: 'ADD_PROJECT',
  UPDATE_PROJECT: 'UPDATE_PROJECT',
  TOGGLE_CHECKIN: 'TOGGLE_CHECKIN',
  IMPORT_STATE: 'IMPORT_STATE',
}

export function reducer(state, action) {
  switch (action.type) {
    case ACTIONS.ADD_LOG: {
      const entry = {
        id: uid('log'),
        createdAt: new Date().toISOString(),
        date: action.payload.date || todayISO(),
        kind: action.payload.kind || 'Nota', // Tarefa | Evento | Nota | Ideia
        status: action.payload.status || 'Caixa de entrada',
        area: action.payload.area || 'Geral',
        projectId: action.payload.projectId || null,
        text: action.payload.text || '',
      }
      return { ...state, logEntries: [entry, ...state.logEntries] }
    }

    case ACTIONS.UPDATE_LOG: {
      const { id, patch } = action.payload
      return { ...state, logEntries: state.logEntries.map(e => (e.id === id ? { ...e, ...patch } : e)) }
    }

    case ACTIONS.ADD_TASK: {
      const task = {
        id: uid('task'),
        createdAt: new Date().toISOString(),
        title: action.payload.title || '',
        notes: action.payload.notes || '',
        status: action.payload.status || 'Próxima', // Backlog | Próxima | Em andamento | Aguardando | Concluída | Cancelada
        due: action.payload.due || null, // YYYY-MM-DD
        priority: action.payload.priority || 'Média',
        area: action.payload.area || 'Geral',
        projectId: action.payload.projectId || null,
      }
      return { ...state, tasks: [task, ...state.tasks] }
    }

    case ACTIONS.UPDATE_TASK: {
      const { id, patch } = action.payload
      return { ...state, tasks: state.tasks.map(t => (t.id === id ? { ...t, ...patch } : t)) }
    }

    case ACTIONS.ADD_PROJECT: {
      const project = {
        id: uid('proj'),
        createdAt: new Date().toISOString(),
        name: action.payload.name || '',
        outcome: action.payload.outcome || '',
        status: action.payload.status || 'Ativo', // Ativo | Em pausa | Concluído
        area: action.payload.area || 'Geral',
        due: action.payload.due || null,
      }
      return { ...state, projects: [project, ...state.projects] }
    }

    case ACTIONS.UPDATE_PROJECT: {
      const { id, patch } = action.payload
      return { ...state, projects: state.projects.map(p => (p.id === id ? { ...p, ...patch } : p)) }
    }

    case ACTIONS.TOGGLE_CHECKIN: {
      const { habitId, date } = action.payload
      const existing = state.checkins.find(c => c.habitId === habitId && c.date === date)
      if (existing) {
        return { ...state, checkins: state.checkins.filter(c => !(c.habitId === habitId && c.date === date)) }
      }
      const checkin = { id: uid('chk'), habitId, date, createdAt: new Date().toISOString() }
      return { ...state, checkins: [checkin, ...state.checkins] }
    }

    case ACTIONS.IMPORT_STATE: {
      return action.payload
    }

    default:
      return state
  }
}
