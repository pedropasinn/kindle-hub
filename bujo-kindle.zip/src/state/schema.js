import { uid } from '../utils/id.js'
import { todayISO } from '../utils/dates.js'

export function createInitialState() {
  const t = todayISO()
  return {
    meta: { version: 1, createdAt: new Date().toISOString() },
    tasks: [],
    projects: [],
    logEntries: [],
    habits: [
      { id: uid('habit'), name: 'Ler 10 páginas', active: true },
      { id: uid('habit'), name: 'Caminhar', active: true },
      { id: uid('habit'), name: 'Estudo focado', active: true },
      { id: uid('habit'), name: 'Sono 7h+', active: true },
    ],
    checkins: [],
    ui: { lastOpened: t },
  }
}
