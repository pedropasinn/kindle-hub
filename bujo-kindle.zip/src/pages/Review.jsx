import Header from '../components/Header.jsx'
import ItemCard from '../components/ItemCard.jsx'
import { useApp } from '../state/AppState.jsx'
import { todayISO, formatDateBR } from '../utils/dates.js'

export default function Review() {
  const { state } = useApp()
  const t = todayISO()

  const overdue = state.tasks.filter(x => x.due && x.due < t && !['Concluída', 'Cancelada'].includes(x.status)).slice(0, 20)
  const inbox = state.logEntries.filter(e => e.status === 'Caixa de entrada').slice(0, 20)
  const activeProjects = state.projects.filter(p => p.status === 'Ativo').slice(0, 20)

  return (
    <div className="page-container">
      <Header title="Revisão" backTo="/" />

      <div className="section-container">
        <h2>Checklist rápido</h2>
        <div className="item-content">
          Passe pela caixa de entrada e decida: arquivar (Concluído), migrar, ou virar tarefa/projeto. Depois olhe atrasadas e faça o “triângulo” clássico: fazer, reagendar ou cancelar. Por fim, confira se cada projeto ativo tem pelo menos uma próxima ação.
        </div>
      </div>

      <div className="section-container">
        <h2>Atrasadas</h2>
        {overdue.length === 0 ? <div className="empty-state">Nada atrasado.</div> : overdue.map(x => (
          <ItemCard key={x.id} title={x.title} meta={`vence ${formatDateBR(x.due)} • ${x.area}`} />
        ))}
      </div>

      <div className="section-container">
        <h2>Caixa de entrada</h2>
        {inbox.length === 0 ? <div className="empty-state">Vazia.</div> : inbox.map(e => (
          <ItemCard key={e.id} title={`${e.kind}: ${e.text}`} meta={`${e.area} • ${formatDateBR(e.date)}`} />
        ))}
      </div>

      <div className="section-container">
        <h2>Projetos ativos</h2>
        {activeProjects.length === 0 ? <div className="empty-state">Sem projetos ativos.</div> : activeProjects.map(p => (
          <ItemCard key={p.id} title={p.name} meta={`${p.area}`} >{p.outcome}</ItemCard>
        ))}
      </div>
    </div>
  )
}
