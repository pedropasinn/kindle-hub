import Header from '../components/Header.jsx'
import ItemCard from '../components/ItemCard.jsx'
import { useApp } from '../state/AppState.jsx'
import { ACTIONS } from '../state/reducer.js'
import { todayISO, formatDateBR } from '../utils/dates.js'

export default function Log() {
  const { state, dispatch } = useApp()

  function add(e) {
    e.preventDefault()
    const form = e.currentTarget
    const text = form.text.value.trim()
    if (!text) return
    dispatch({
      type: ACTIONS.ADD_LOG,
      payload: {
        text,
        kind: form.kind.value,
        status: form.status.value,
        area: form.area.value,
        date: form.date.value || todayISO(),
      },
    })
    form.reset()
  }

  const entries = state.logEntries.slice(0, 200)

  return (
    <div className="page-container">
      <Header title="Log diário" backTo="/" />

      <div className="form-section">
        <h2>Adicionar</h2>
        <form onSubmit={add}>
          <div className="form-group">
            <label>Texto</label>
            <textarea name="text" placeholder="Escreva no estilo bullet: curto e claro" />
          </div>
          <div className="form-group">
            <label>Tipo</label>
            <select name="kind" defaultValue="Nota">
              <option>Tarefa</option>
              <option>Evento</option>
              <option>Nota</option>
              <option>Ideia</option>
            </select>
          </div>
          <div className="form-group">
            <label>Status</label>
            <select name="status" defaultValue="Caixa de entrada">
              <option>Caixa de entrada</option>
              <option>Ativo</option>
              <option>Migrado</option>
              <option>Concluído</option>
              <option>Cancelado</option>
            </select>
          </div>
          <div className="form-group">
            <label>Área</label>
            <input name="area" defaultValue="Geral" />
          </div>
          <div className="form-group">
            <label>Data</label>
            <input name="date" type="date" defaultValue={todayISO()} />
          </div>
          <button className="btn btn-primary" type="submit">Salvar</button>
        </form>
      </div>

      <div className="list-section">
        <h2>Últimos itens</h2>
        {entries.length === 0 ? (
          <div className="empty-state">Seu log ainda está vazio.</div>
        ) : (
          entries.map(e => (
            <ItemCard
              key={e.id}
              title={`${e.kind} • ${e.text.slice(0, 60)}${e.text.length > 60 ? '…' : ''}`}
              meta={`${e.status} • ${e.area} • ${formatDateBR(e.date)}`}
              actions={
                <>
                  <button className="btn-small" onClick={() => dispatch({ type: ACTIONS.UPDATE_LOG, payload: { id: e.id, patch: { status: 'Concluído' } } })}>Concluir</button>
                  <button className="btn-small" onClick={() => dispatch({ type: ACTIONS.UPDATE_LOG, payload: { id: e.id, patch: { status: 'Migrado' } } })}>Migrar</button>
                </>
              }
            >
              {e.text}
            </ItemCard>
          ))
        )}
      </div>
    </div>
  )
}
