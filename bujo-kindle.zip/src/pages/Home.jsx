import { Link } from 'react-router-dom'
import { useEffect, useState } from 'react'
import { formatTimeHHMM } from '../utils/dates.js'

export default function Home() {
  const [now, setNow] = useState(new Date())

  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000)
    return () => clearInterval(t)
  }, [])

  const dateStr = now.toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' })
  const timeStr = formatTimeHHMM(now)

  return (
    <div className="container">
      <div className="clock-container">
        <div className="clock">{timeStr}</div>
        <div className="date">{dateStr}</div>
      </div>

      <div className="nav-buttons">
        <Link className="nav-button" to="/today">Hoje</Link>
        <Link className="nav-button" to="/log">Log diário</Link>
        <Link className="nav-button" to="/tasks">Tarefas</Link>
        <Link className="nav-button" to="/projects">Projetos</Link>
        <Link className="nav-button" to="/habits">Hábitos</Link>
        <Link className="nav-button" to="/review">Revisão</Link>
        <Link className="nav-button" to="/settings">Ajustes</Link>
      </div>
    </div>
  )
}
