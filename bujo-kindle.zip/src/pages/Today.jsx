import { Link } from 'react-router-dom'
import Header from '../components/Header.jsx'
import ItemCard from '../components/ItemCard.jsx'
import { useApp } from '../state/AppState.jsx'
import { ACTIONS } from '../state/reducer.js'
import { todayISO, formatDateBR } from '../utils/dates.js'

export default function Today() {
  const { state, dispatch } = useApp()
  const date = todayISO()

  const tasksToday = state.tasks
    .filter(t => t.status !== 'Concluída' && t.status !== 'Cancelada')
    .filter(t => t.due === date || ['Próxima', 'Em andamento'].includes(t.status))
    .slice(0, 20)

  const logInbox = state.logEntries.filter(e => e.status === 'Caixa de entrada').slice(0, 20)

  function quickAddLog(e) {
    e.preventDefault()
    const form = e.currentTarget
    const text = form.text.value.trim()
    const kind = form.kind.value
    if (!text) return
    dispatch({ type: ACTIONS.ADD_LOG, payload: { text, kind, date } })
    form.reset()
  }

  return (
    <div className="page-container">
      <Header title="Hoje" backTo="/" />

      <div className="section-container">
        <h2>Captura rápida</h2>
        <form onSubmit={quickAddLog} className="form-group">
          <label>Texto</label>
          <textarea name="text" placeholder="Uma nota, tarefa, evento, ideia..." />
          <label style={{ marginTop: 10 }}>Tipo</label>
          <select name="kind" defaultValue="Nota">
            <option>Tarefa</option>
            <option>Evento</option>
            <option>Nota</option>
            <option>Ideia</option>
          </select>
          <div style={{ marginTop: 12 }}>
            <button className="btn btn-primary" type="submit">Adicionar</button>
            <Link className="btn" to="/log">Abrir log</Link>
          </div>
        </form>
      </div>

      <div className="section-container">
        <h2>Foco de hoje</h2>
        {tasksToday.length === 0 ? (
          <div className="empty-state">Sem tarefas no foco. Que tal puxar algo do backlog?</div>
        ) : (
          tasksToday.map(t => (
            <ItemCard
              key={t.id}
              title={t.title}
              meta={`${t.priority} • ${t.area}` + (t.due ? ` • vence ${formatDateBR(t.due)}` : '')}
              completed={t.status === 'Concluída'}
              actions={
                <>
                  <button className="btn-small" onClick={() => dispatch({ type: ACTIONS.UPDATE_TASK, payload: { id: t.id, patch: { status: 'Concluída' } } })}>Concluir</button>
                  <button className="btn-small" onClick={() => dispatch({ type: ACTIONS.UPDATE_TASK, payload: { id: t.id, patch: { status: 'Em andamento' } } })}>Em andamento</button>
                </>
              }
            >
              {t.notes || ''}
            </ItemCard>
          ))
        )}
      </div>

      <div className="section-container">
        <h2>Caixa de entrada</h2>
        {logInbox.length === 0 ? (
          <div className="empty-state">Nada na caixa de entrada.</div>
        ) : (
          logInbox.map(e => (
            <ItemCard
              key={e.id}
              title={`${e.kind}: ${e.text.slice(0, 40)}${e.text.length > 40 ? '…' : ''}`}
              meta={`${e.area} • ${formatDateBR(e.date)}`}
              actions={
                <>
                  <button className="btn-small" onClick={() => dispatch({ type: ACTIONS.UPDATE_LOG, payload: { id: e.id, patch: { status: 'Ativo' } } })}>Ativar</button>
                  <button className="btn-small" onClick={() => dispatch({ type: ACTIONS.UPDATE_LOG, payload: { id: e.id, patch: { status: 'Migrado' } } })}>Migrar</button>
                </>
              }
            >
              {e.text}
            </ItemCard>
          ))
        )}
      </div>
    </div>
  )
}
