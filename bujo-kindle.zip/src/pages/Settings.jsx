import { useRef, useState } from 'react'
import Header from '../components/Header.jsx'
import { useApp } from '../state/AppState.jsx'
import { ACTIONS } from '../state/reducer.js'
import { exportJSON, importJSON } from '../utils/storage.js'

export default function Settings() {
  const { state, dispatch } = useApp()
  const [msg, setMsg] = useState(null)
  const fileRef = useRef(null)

  function download() {
    const data = exportJSON(state)
    const blob = new Blob([data], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'bujo-backup.json'
    document.body.appendChild(a)
    a.click()
    a.remove()
    URL.revokeObjectURL(url)
    setMsg({ type: 'success', text: 'Backup baixado.' })
  }

  async function onImportFile(e) {
    const f = e.target.files?.[0]
    if (!f) return
    try {
      const text = await f.text()
      const obj = importJSON(text)
      dispatch({ type: ACTIONS.IMPORT_STATE, payload: obj })
      setMsg({ type: 'success', text: 'Backup importado.' })
    } catch (err) {
      setMsg({ type: 'error', text: 'Falha ao importar: ' + (err?.message || 'erro') })
    } finally {
      e.target.value = ''
    }
  }

  return (
    <div className="page-container">
      <Header title="Ajustes" backTo="/" />

      {msg ? <div className={'message ' + msg.type}>{msg.text}</div> : null}

      <div className="section-container">
        <h2>Backup</h2>
        <button className="btn btn-primary" onClick={download}>Exportar JSON</button>
      </div>

      <div className="section-container">
        <h2>Importar</h2>
        <input ref={fileRef} type="file" accept="application/json" onChange={onImportFile} />
        <div className="item-meta" style={{ marginTop: 10 }}>
          Dica: isso substitui seus dados atuais pelos do arquivo.
        </div>
      </div>
    </div>
  )
}
