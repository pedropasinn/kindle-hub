import { useMemo, useState } from 'react'
import Header from '../components/Header.jsx'
import ItemCard from '../components/ItemCard.jsx'
import { useApp } from '../state/AppState.jsx'
import { ACTIONS } from '../state/reducer.js'
import { todayISO, formatDateBR } from '../utils/dates.js'

export default function Tasks() {
  const { state, dispatch } = useApp()
  const [filter, setFilter] = useState('Próxima')

  const filtered = useMemo(() => {
    const all = state.tasks
    if (filter === 'Atrasadas') {
      const t = todayISO()
      return all.filter(x => x.due && x.due < t && !['Concluída', 'Cancelada'].includes(x.status))
    }
    if (filter === 'Todas') return all
    return all.filter(x => x.status === filter)
  }, [state.tasks, filter])

  function add(e) {
    e.preventDefault()
    const form = e.currentTarget
    const title = form.title.value.trim()
    if (!title) return
    dispatch({
      type: ACTIONS.ADD_TASK,
      payload: {
        title,
        notes: form.notes.value.trim(),
        status: form.status.value,
        due: form.due.value || null,
        priority: form.priority.value,
        area: form.area.value,
      },
    })
    form.reset()
  }

  return (
    <div className="page-container">
      <Header title="Tarefas" backTo="/" />

      <div className="form-section">
        <h2>Nova tarefa</h2>
        <form onSubmit={add}>
          <div className="form-group">
            <label>Título</label>
            <input name="title" placeholder="Ex.: marcar consulta, estudar capítulo 3..." />
          </div>
          <div className="form-group">
            <label>Notas</label>
            <textarea name="notes" placeholder="Contexto, links, próximos passos..." />
          </div>
          <div className="form-group">
            <label>Status</label>
            <select name="status" defaultValue="Próxima">
              <option>Backlog</option>
              <option>Próxima</option>
              <option>Em andamento</option>
              <option>Aguardando</option>
              <option>Concluída</option>
              <option>Cancelada</option>
            </select>
          </div>
          <div className="form-group">
            <label>Prazo</label>
            <input name="due" type="date" />
          </div>
          <div className="form-group">
            <label>Prioridade</label>
            <select name="priority" defaultValue="Média">
              <option>Alta</option>
              <option>Média</option>
              <option>Baixa</option>
            </select>
          </div>
          <div className="form-group">
            <label>Área</label>
            <input name="area" defaultValue="Geral" />
          </div>
          <button className="btn btn-primary" type="submit">Adicionar</button>
        </form>
      </div>

      <div className="section-container">
        <h2>Filtros</h2>
        <div className="nav-chips">
          {['Próxima', 'Em andamento', 'Aguardando', 'Backlog', 'Atrasadas', 'Concluída', 'Todas'].map(x => (
            <button key={x} className="nav-chip" onClick={() => setFilter(x)}>{x}</button>
          ))}
        </div>
      </div>

      <div className="list-section">
        <h2>Lista</h2>
        {filtered.length === 0 ? (
          <div className="empty-state">Nada aqui por enquanto.</div>
        ) : (
          filtered.map(t => (
            <ItemCard
              key={t.id}
              title={t.title}
              meta={`${t.priority} • ${t.area}` + (t.due ? ` • vence ${formatDateBR(t.due)}` : '')}
              completed={t.status === 'Concluída'}
              actions={
                <>
                  {t.status !== 'Concluída' ? (
                    <button className="btn-small" onClick={() => dispatch({ type: ACTIONS.UPDATE_TASK, payload: { id: t.id, patch: { status: 'Concluída' } } })}>Concluir</button>
                  ) : null}
                  <button className="btn-small" onClick={() => dispatch({ type: ACTIONS.UPDATE_TASK, payload: { id: t.id, patch: { status: 'Próxima' } } })}>Reabrir</button>
                  <button className="btn-small" onClick={() => dispatch({ type: ACTIONS.UPDATE_TASK, payload: { id: t.id, patch: { status: 'Cancelada' } } })}>Cancelar</button>
                </>
              }
            >
              {t.notes}
            </ItemCard>
          ))
        )}
      </div>
    </div>
  )
}
