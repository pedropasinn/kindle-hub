import Header from '../components/Header.jsx'
import { useApp } from '../state/AppState.jsx'
import { ACTIONS } from '../state/reducer.js'
import { todayISO } from '../utils/dates.js'

export default function Habits() {
  const { state, dispatch } = useApp()
  const date = todayISO()

  const activeHabits = state.habits.filter(h => h.active)
  const doneSet = new Set(state.checkins.filter(c => c.date === date).map(c => c.habitId))

  return (
    <div className="page-container">
      <Header title="Hábitos" backTo="/" />

      <div className="habits-section">
        <h2>Hoje</h2>
        {activeHabits.length === 0 ? (
          <div className="empty-state">Sem hábitos ativos.</div>
        ) : (
          <div className="habits-grid">
            {activeHabits.map(h => {
              const done = doneSet.has(h.id)
              return (
                <div key={h.id} className={'habit-item' + (done ? ' completed' : '')}>
                  <input
                    className="habit-checkbox"
                    type="checkbox"
                    checked={done}
                    onChange={() => dispatch({ type: ACTIONS.TOGGLE_CHECKIN, payload: { habitId: h.id, date } })}
                  />
                  <div className="habit-label">{h.name}</div>
                </div>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}
