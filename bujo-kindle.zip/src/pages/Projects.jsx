import { useMemo, useState } from 'react'
import Header from '../components/Header.jsx'
import ItemCard from '../components/Header.jsx'
import { useApp } from '../state/AppState.jsx'
import { ACTIONS } from '../state/reducer.js'
import { formatDateBR } from '../utils/dates.js'
import Card from '../components/ItemCard.jsx'

export default function Projects() {
  const { state, dispatch } = useApp()
  const [filter, setFilter] = useState('Ativo')

  const projects = useMemo(() => {
    if (filter === 'Todos') return state.projects
    return state.projects.filter(p => p.status === filter)
  }, [state.projects, filter])

  const tasksByProject = useMemo(() => {
    const map = new Map()
    for (const t of state.tasks) {
      const k = t.projectId || '__none__'
      map.set(k, (map.get(k) || 0) + (t.status !== 'Concluída' && t.status !== 'Cancelada' ? 1 : 0))
    }
    return map
  }, [state.tasks])

  function add(e) {
    e.preventDefault()
    const form = e.currentTarget
    const name = form.name.value.trim()
    if (!name) return
    dispatch({
      type: ACTIONS.ADD_PROJECT,
      payload: {
        name,
        outcome: form.outcome.value.trim(),
        status: form.status.value,
        area: form.area.value,
        due: form.due.value || null,
      },
    })
    form.reset()
  }

  return (
    <div className="page-container">
      <Header title="Projetos" backTo="/" />

      <div className="form-section">
        <h2>Novo projeto</h2>
        <form onSubmit={add}>
          <div className="form-group">
            <label>Nome</label>
            <input name="name" placeholder="Ex.: Preparar prova, Organizar finanças..." />
          </div>
          <div className="form-group">
            <label>Resultado (opcional)</label>
            <textarea name="outcome" placeholder="Como você sabe que terminou?" />
          </div>
          <div className="form-group">
            <label>Status</label>
            <select name="status" defaultValue="Ativo">
              <option>Ativo</option>
              <option>Em pausa</option>
              <option>Concluído</option>
            </select>
          </div>
          <div className="form-group">
            <label>Área</label>
            <input name="area" defaultValue="Geral" />
          </div>
          <div className="form-group">
            <label>Prazo</label>
            <input name="due" type="date" />
          </div>
          <button className="btn btn-primary" type="submit">Adicionar</button>
        </form>
      </div>

      <div className="section-container">
        <h2>Filtros</h2>
        <div className="nav-chips">
          {['Ativo', 'Em pausa', 'Concluído', 'Todos'].map(x => (
            <button key={x} className="nav-chip" onClick={() => setFilter(x)}>{x}</button>
          ))}
        </div>
      </div>

      <div className="list-section">
        <h2>Lista</h2>
        {projects.length === 0 ? (
          <div className="empty-state">Sem projetos.</div>
        ) : (
          projects.map(p => {
            const openTasks = tasksByProject.get(p.id) || 0
            const meta = `${p.status} • ${p.area}` + (p.due ? ` • prazo ${formatDateBR(p.due)}` : '') + ` • ${openTasks} tarefas abertas`
            return (
              <Card key={p.id} title={p.name} meta={meta} completed={p.status === 'Concluído'}
                actions={
                  <>
                    <button className="btn-small" onClick={() => dispatch({ type: ACTIONS.UPDATE_PROJECT, payload: { id: p.id, patch: { status: 'Ativo' } } })}>Ativar</button>
                    <button className="btn-small" onClick={() => dispatch({ type: ACTIONS.UPDATE_PROJECT, payload: { id: p.id, patch: { status: 'Em pausa' } } })}>Pausar</button>
                    <button className="btn-small" onClick={() => dispatch({ type: ACTIONS.UPDATE_PROJECT, payload: { id: p.id, patch: { status: 'Concluído' } } })}>Concluir</button>
                  </>
                }
              >
                {p.outcome}
              </Card>
            )
          })
        )}
      </div>
    </div>
  )
}
