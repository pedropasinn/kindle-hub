import { Routes, Route, Navigate } from 'react-router-dom'
import { AppProvider } from './state/AppState.jsx'

import Home from './pages/Home.jsx'
import Today from './pages/Today.jsx'
import Log from './pages/Log.jsx'
import Tasks from './pages/Tasks.jsx'
import Projects from './pages/Projects.jsx'
import Habits from './pages/Habits.jsx'
import Review from './pages/Review.jsx'
import Settings from './pages/Settings.jsx'

export default function App() {
  return (
    <AppProvider>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/today" element={<Today />} />
        <Route path="/log" element={<Log />} />
        <Route path="/tasks" element={<Tasks />} />
        <Route path="/projects" element={<Projects />} />
        <Route path="/habits" element={<Habits />} />
        <Route path="/review" element={<Review />} />
        <Route path="/settings" element={<Settings />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </AppProvider>
  )
}
