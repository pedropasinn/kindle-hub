const KEY = 'bujo_v1'

export function loadState() {
  try {
    const raw = localStorage.getItem(KEY)
    if (!raw) return null
    return JSON.parse(raw)
  } catch {
    return null
  }
}

export function saveState(state) {
  try {
    localStorage.setItem(KEY, JSON.stringify(state))
  } catch {
    // se o storage estiver cheio/indisponível, a app continua funcionando em memória
  }
}

export function exportJSON(state) {
  return JSON.stringify(state, null, 2)
}

export function importJSON(text) {
  const obj = JSON.parse(text)
  // validação minimalista
  if (!obj || typeof obj !== 'object') throw new Error('JSON inválido')
  return obj
}
