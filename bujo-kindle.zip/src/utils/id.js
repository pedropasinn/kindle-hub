export function uid(prefix = 'id') {
  // crypto.randomUUID é ótimo, mas nem todo Kindle/browser antigo suporta.
  const rnd = (n = 16) => Array.from({ length: n }, () => Math.floor(Math.random() * 16).toString(16)).join('')
  try {
    if (typeof crypto !== 'undefined' && crypto.randomUUID) return `${prefix}_${crypto.randomUUID()}`
  } catch {}
  return `${prefix}_${Date.now().toString(16)}_${rnd(8)}`
}
