export default function ItemCard({ title, meta, children, actions, completed }) {
  return (
    <div className={'item fade-in' + (completed ? ' completed' : '')}>
      <div className="item-title">{title}</div>
      {meta ? <div className="item-meta">{meta}</div> : null}
      {children ? <div className="item-content">{children}</div> : null}
      {actions ? <div className="item-actions">{actions}</div> : null}
    </div>
  )
}
