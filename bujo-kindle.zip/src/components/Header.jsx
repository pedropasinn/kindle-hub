import { Link } from 'react-router-dom'

export default function Header({ title, backTo = '/', right }) {
  return (
    <header>
      <div className="header-top">
        <h1>{title}</h1>
        {right || null}
      </div>
      <div>
        <Link className="back-link" to={backTo}>Voltar</Link>
      </div>
    </header>
  )
}
