# BuJo Kindle (React + Vite)

Projeto base para um Bullet Journal offline-first simples, com:
- Log diário (captura rápida)
- Tarefas
- Projetos
- Hábitos (check-in por dia)
- Export/Import JSON

## Rodar localmente
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
npm run preview
```

Os dados ficam em `localStorage` (chave `bujo_v1`).
